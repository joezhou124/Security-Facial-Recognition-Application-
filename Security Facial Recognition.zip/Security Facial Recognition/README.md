Requirements
• Python 3.3+ or Python 2.7

• macOS or Linux (Not Windows)

• For Install "face_recognition and dlib" https://github.com/ageitgey/face_recognition

• Chrome Driver : https://chromedriver.chromium.org/downloads